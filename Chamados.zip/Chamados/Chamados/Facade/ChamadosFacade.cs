﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Application;
using Entities;

namespace Facade
{
    public class ChamadosFacade
    {
        public static ChamadosFacade Instancia
        {
            get { return new ChamadosFacade(); }
        }

        public Chamados ObterChamado(int id)
        {
            return ChamadosApplication.Instancia.ObterChamado(id);
        }

        public void InserirChamado(Chamados NovoChamado)
        {
            ChamadosApplication.Instancia.InserirChamado(NovoChamado);
        }

        public void AlterarCurriculo(Chamados chamado)
        {
            ChamadosApplication.Instancia.AlterarCurriculo(chamado);
        }

        public void ExcluirChamado(Chamados chamado)
        {
            ChamadosApplication.Instancia.ExcluirChamado(chamado);
        }

        public List<string> listaStatus(int idPerfil)
        {
           return ChamadosApplication.Instancia.listaStatus(idPerfil);
        }

        public List<string> InsereChamado(Chamados chamado)
        {
            return ChamadosApplication.Instancia.InsereChamado(chamado);
        }

        public IList<Chamados> ListarChamados(Chamados chamados)
        {
            return ChamadosApplication.Instancia.ListarChamados(chamados);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;
using Application;

namespace Facade
{
    public class UsuarioFacade
    {
        public static UsuarioFacade Instancia
        {
            get { return new UsuarioFacade(); }
        }

        public Usuario_cadastro ObterLogin_senha(string Login)
        {
            return UsuarioApplication.Instancia.ObterLogin_senha(Login);
        }

        public List<Usuario_cadastro> ListarUsuarios()
        {
            return UsuarioApplication.Instancia.ListarUsuarios();
        }

        public List<Usuario_Perfil> listaPerfil()
        {
            return UsuarioApplication.Instancia.listaPerfil();
        }

        public void InsereUsuario(Usuario_cadastro Usu)
        {
            UsuarioApplication.Instancia.InsereUsuario(Usu);
        }

        public Usuario_Perfil listaPerfils(Usuario_Perfil cadastro)
        {
            return UsuarioApplication.Instancia.listaPerfisl(cadastro);
        }

        public List<Usuario_Perfil> listaPerfilUsu(int IdPerfil)
        {
            return UsuarioApplication.Instancia.listaPerfilUsu(IdPerfil);
        }

        public List<string> listaPerfilUsuario(Usuario_Perfil Perfil)
        {
            return UsuarioApplication.Instancia.listaPerfilUsuario(Perfil);
        }

        public IList<lMenuLista> ListarMmenus(Usuario_cadastro usuario)
        {
            return UsuarioApplication.Instancia.ListarMmenus(usuario);
        }

    }
}

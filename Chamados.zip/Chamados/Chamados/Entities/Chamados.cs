﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;

namespace Entities
{
    [Serializable]
    [ActiveRecord(Table="chamados")]
   public  class Chamados
    {
        [PrimaryKey(Column = "id_chamado", Generator = PrimaryKeyType.Identity)]
        public int Id_chamado { get; set; }

        [Property(Column = "titulo", NotNull = true)]
        public string Titulo { get; set; }

        [Property(Column = "id_perfil", NotNull = false)]
        public int Id_perfil { get; set; }

        [Property(Column = "descricao", NotNull = true)]
        public string Descricao { get; set; }

        [Property(Column = "img", NotNull = true)]
        public string Img { get; set; }

        [Property(Column = "dt_abertura", NotNull = true)]
        public string Dt_abertura { get; set; }

        [Property(Column = "dt_finalizado", NotNull = true)]
        public string Dt_finalizado { get; set; }

        [Property(Column = "id_status_fk", NotNull = false)]
        public int Id_status_fk { get; set; }

        [Property(Column = "id_usuario_criacao", NotNull = true)]
        public int Id_usuario_criacao { get; set; }

        [Property(Column = "id_usuario_alteracao", NotNull = true)]
        public int Id_usuario_alteracao { get; set; }

        [Property(Column = "id_usuario_exclusao", NotNull = true)]
        public int Id_usuario_exclusao { get; set; }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;

namespace Entities
{
    [Serializable]
    [ActiveRecord(Table = "UsuarioMenu")]
    public class UsuarioMenu
    {
        [PrimaryKey(Column = "idUsuario", Generator = PrimaryKeyType.Identity)]
        public int IdUsuario { get; set; }

        [Property(Column = "idMenuFK", NotNull = false)]
        public int IdMenuFK { get; set; }

        
    }
}

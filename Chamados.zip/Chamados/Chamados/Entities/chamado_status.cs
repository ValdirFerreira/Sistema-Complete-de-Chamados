﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using Castle.ActiveRecord;



namespace Entities
{
    [Serializable]
    [ActiveRecord(Table = "chamado_status")]
    public class chamado_status
    {

        /// <summary>
        /// Indentificador do Status 
        /// </summary>
        [PrimaryKey(Column = "idStatus", Generator = PrimaryKeyType.Identity)]
        public int IdStatus { get; set; }

        ///<sumary>
        ///Nome do Status 
        ///</sumary>


        [Property(Column = "strStatus", NotNull = true)]
        public string StrStatus { get; set; }


    }
}

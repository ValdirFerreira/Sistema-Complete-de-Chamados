﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;


namespace Entities
{
    [Serializable]
    [ActiveRecord(Table = "PerfilMenu")]
    public  class PerfilMenu
    {

        [PrimaryKey(Column = "id_perfil", Generator = PrimaryKeyType.Identity)]
        public int Id_perfil { get; set; }

        [Property(Column = "idMenuFK", NotNull = false)]
        public int IdMenuFK { get; set; }
    }
}

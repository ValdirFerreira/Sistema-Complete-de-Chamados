﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;

namespace Entities
{
    [Serializable]
    [ActiveRecord(Table="usuario_perfil")]
    public class Usuario_Perfil
    {
        [PrimaryKey(Column = "id_perfil",Generator = PrimaryKeyType.Identity)]
        public int IdPerfil { get; set; }

        [Property(Column = "str_tipo", NotNull = false)]
        public string strTipo { get; set; }
    }
}

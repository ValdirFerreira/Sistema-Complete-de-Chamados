﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;

namespace Entities
{
    [Serializable]
    [ActiveRecord(Table = "menu")]
    public class lMenuLista
    {
        [PrimaryKey(Column = "idMenu", Generator = PrimaryKeyType.Identity)]
        public int IdMenu { get; set; }

        [Property(Column = "strNome", NotNull = false)]
        public string StrNome { get; set; }

        [Property(Column = "strURL", NotNull = false)]
        public string StrURL { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;

namespace Entities
{
    [Serializable]
    [ActiveRecord(Table = "usuario_cadastro")]
    public class Usuario_cadastro
    {
        /// <summary>
        /// id do usuario
        /// </summary>
        [PrimaryKey(Column="id_usuario",Generator = PrimaryKeyType.Identity)]
        public int Id_usuario{get;set;}

        /// <summary>
        /// nome do usuário
        /// </summary>
        [Property(Column = "nome", NotNull = true)]
        public string Nome { get; set; }

        /// <summary>
        /// apelido do usuario 
        /// </summary>
        [Property(Column = "apelido", NotNull = true)]
        public string Apelido { get; set; }

        /// <summary>
        /// Senha usuário
        /// </summary>
        [Property(Column = "senha", NotNull = true)]
        public string Senha { get; set; }


        [Property(Column = "id_perfil_fk", NotNull = true)]
        public int Id_perfil_fk { get; set; }

    }
}

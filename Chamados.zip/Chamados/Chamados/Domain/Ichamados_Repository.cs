﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;

namespace Domain
{

    public interface Ichamados_Repository
    {

        Chamados ObterChamado(int id);
        List<Chamados> ListarChamados();


        void InserirChamado(Chamados NovoChamado);
        void AlterarCurriculo(Chamados chamado);
        void ExcluirChamado(Chamados chamado);
        void ExcluirChamado(int id);
        List<string> listaStatus(int idPerfil);
        List<string> InsereChamado(Chamados NovoChamado);

        IList<Chamados> ListarChamados(Chamados chamados);
        

        

    }

}

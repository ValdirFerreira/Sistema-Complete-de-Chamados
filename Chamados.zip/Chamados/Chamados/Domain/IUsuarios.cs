﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;

namespace Domain
{
    public interface IUsuarios
    {
        Usuario_cadastro ObterLogin_senha(string Login);
        List<Usuario_cadastro> ListarUsuarios();
        List<Usuario_Perfil> listaPerfil();

        Usuario_Perfil listaPerfils(Usuario_Perfil perfil);
        List<Usuario_Perfil> listaPerfilUsu( int Idperfil);
        void InsereUsuario(Usuario_cadastro Usuario);

        List<string> listaPerfilUsuario(Usuario_Perfil perfil);
       
       

        


     

    }
}

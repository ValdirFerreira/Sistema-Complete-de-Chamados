﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;

namespace Domain
{

   public interface Ichamado_statusRepository
	{
       chamado_status ObterChamado(int id);
       List<chamado_status> ListarChamados();

       void InserirChamado(chamado_status NovoChamado);
       void AlterarCurriculo(chamado_status chamado);
       void ExcluirChamado(chamado_status chamado);
       void ExcluirChamado(int id);
	}
    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entities;
using Model;

namespace WebChamadosLms
{
    public partial class ListarChamados : System.Web.UI.Page
    {
        ChamadosModel _chamados = new ChamadosModel();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            listar();
        }

        public void listar()
        {
            Chamados chama = new Chamados();
            chama.Descricao = "teste";
            

            ListaChamados.DataSource  = _chamados.ListarChamados(chama);
           
            ListaChamados.DataBind();
           
        }

        protected void ListaChamados_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            ListaChamados.PageIndex = e.NewPageIndex;
            ListaChamados.DataBind();
        }

    }
}
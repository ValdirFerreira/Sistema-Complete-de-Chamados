﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Model;
using Entities;

namespace WebChamadosLms
{
    public partial class Entrar : System.Web.UI.Page
    {

        Model.UsuariosModel _model = new UsuariosModel();

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                lblMensagem.Visible = false;
            }
        }

        protected void Entrar_Click(object sender, EventArgs e)
        {
            Usuario_cadastro Usuario = new Usuario_cadastro();
            Usuario = _model.ObterLogin_senha(txtLogin.Text);

            //Coloca uauário na Sessão 
            Session[Constantes.Instancia.ChaveDadosUsuario] = Usuario;

            //// Recupera dados  do usuario da sessão 
            //Usuario_cadastro usu = new Usuario_cadastro();
            //usu = ((Usuario_cadastro)Session[Constantes.Instancia.ChaveDadosUsuario]);
            if (Usuario != null)
            {
                if (Usuario.Senha == txtSenha.Text && Usuario.Apelido == txtLogin.Text)
                {
                    Response.Redirect("Menu.aspx");
                }
                else
                {
                    lblTitulo.Text = "Login ou Senha Invalido!SSSS";
                    lblMensagem.Visible = true;
                }
            }
         

            
        }
    }
}
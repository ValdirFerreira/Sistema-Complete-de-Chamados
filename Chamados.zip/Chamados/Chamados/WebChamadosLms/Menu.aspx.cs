﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Model;
using Entities;
using System.Data;

namespace WebChamadosLms
{
    public partial class Menu : System.Web.UI.Page
    {

        UsuariosModel _usuarioModel = new UsuariosModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            AcharMetodo();
            carregarlist(); // carrega login 
           
        }


        public void AcharMetodo()
        {
            lListaCompromisso.ItemCommand += lListaCompromisso_ItemCommand;
        }

        public void carregarlist()
        {
            // Recupera dados  do usuario da sessão 
            Usuario_cadastro usu = new Usuario_cadastro();
            usu = ((Usuario_cadastro)Session[Constantes.Instancia.ChaveDadosUsuario]);
            if (usu != null)
            {
                lListaCompromisso.DataSource = _usuarioModel.Listar(usu);
                lListaCompromisso.DataBind();
            }
        }


        #region Eventos
        private void lListaCompromisso_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            var page = string.Empty;
            if (e.CommandName == "selecionar")
            {

                page = e.CommandArgument.ToString();
                if (!string.IsNullOrEmpty(page))
                    Response.Redirect(page);
            }

        }

        #endregion


    }
}
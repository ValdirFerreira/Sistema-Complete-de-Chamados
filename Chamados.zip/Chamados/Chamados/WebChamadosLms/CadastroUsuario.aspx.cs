﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Model;
using Entities;

namespace WebChamadosLms
{
    public partial class CadastroUsuario : System.Web.UI.Page
    {

        Model.UsuariosModel _model = new UsuariosModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CarregaLista();
            }
        }

        void limparCampos()
        {
            txtNome.Text = string.Empty;
            txtApelido.Text = string.Empty;
            txtSenha.Text = string.Empty;
            txtConfirmaSenha.Text = string.Empty;           

        }

        public void CarregaLista()
        {

            lstPerfils.DataSource = 
            _model.listaPerfil();
            lstPerfils.DataValueField = "IdPerfil";
            lstPerfils.DataTextField = "strTipo";
            lstPerfils.DataBind();         
          
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            var Usu = Cadastro();
            try
            {

                _model.InsereUsuario(Usu);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                limparCampos(); 
            }


        }


        public Usuario_cadastro Cadastro()
        {
            Usuario_cadastro Usuario = new Usuario_cadastro();

            Usuario.Nome = txtNome.Text;
            Usuario.Apelido = txtApelido.Text;
            Usuario.Senha = txtSenha.Text;

           

             //int perfil =0 ;
             //switch (lstPerfils.Text)
             //{
             //    case "Administrador":
             //        perfil = 1;
             //        break;

             //    case "Desenvolvedor":
             //        perfil = 2;
             //        break;

             //    case "Analista":
             //        perfil = 3;
             //        break;

             //    case "Homologação":
             //        perfil = 4;
             //        break;

             //    case "Usuário Site":
             //        perfil = 5;
             //        break;              

             //}

            Usuario.Id_perfil_fk = Convert.ToInt32(lstPerfils.SelectedValue);
            return Usuario;
        }

    }
}
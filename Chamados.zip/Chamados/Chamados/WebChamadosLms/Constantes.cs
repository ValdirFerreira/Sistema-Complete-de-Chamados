﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChamadosLms
{
    public class Constantes
    {
        public static Constantes Instancia
        {
            get { return new Constantes(); }
        }

        public  readonly string ChaveDadosUsuario = "ChaveDadosUsuario";

        public readonly string ChaveTipoSessao = "ChaveTipoSessao";

        public readonly string ChaveAlteraSalvar = "ChaveAlteraSalvar";
    }
}
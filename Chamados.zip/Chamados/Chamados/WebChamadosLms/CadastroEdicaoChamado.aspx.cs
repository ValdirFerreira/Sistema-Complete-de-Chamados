﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Model;
using Entities;
using System.IO;


namespace WebChamadosLms
{
    public partial class CadastroEdicaoChamado : System.Web.UI.Page
    {
        UsuariosModel _model = new UsuariosModel();
        ChamadosModel chamadoMovel = new ChamadosModel();

        protected void Page_Load(object sender, EventArgs e)
        {
            AchaEvento();
            if (!IsPostBack)
            {
                DefineSessao("Salvar"); // "Novo" seta sessão quando vem de outra pagina novo cadastro ou visualização

                if (retornaSessao().ToString() == "visao")
                {
                    EventosBotoes(false, "Editar");
                    // Recupera dados  do usuario da sessão 
                    Usuario_cadastro usu = new Usuario_cadastro();
                    usu = ((Usuario_cadastro)Session[Constantes.Instancia.ChaveDadosUsuario]);
                    if (usu != null)
                    {
                        CarregaStatusUsuario(usu.Id_perfil_fk); // incluir id do Usuario para funcionar 
                    }
                }
                else
                {
                    EventosBotoes(false, "Salvar");
                    CarregaStatusUsuario(0);
                    dataHoraChamadoFinalizado.Enabled = false;

                }

                CarregaLista();


            }

        }

        #region Sessioes
        public void DefineSessao(string sessao)
        {
            Session[Constantes.Instancia.ChaveTipoSessao] = sessao;
        }

        public string retornaSessao()
        {
            return Session[Constantes.Instancia.ChaveTipoSessao].ToString();
        }

        //Sessoes de alterar e salvar chamados 
        public void DefineAlteraSalvar(string sessao)
        {
            Session[Constantes.Instancia.ChaveAlteraSalvar] = sessao;
        }

        public string retornarAlteraSalvar()
        {
            return Session[Constantes.Instancia.ChaveAlteraSalvar].ToString();
        }

        #endregion

        #region metodos novos

        public void CarregaLista()
        {
            Usuario_cadastro usu = new Usuario_cadastro();
            usu = ((Usuario_cadastro)Session[Constantes.Instancia.ChaveDadosUsuario]);
            if (usu != null)
            {
                Usuario_Perfil cadastro = new Usuario_Perfil();
                cadastro.IdPerfil = usu.Id_perfil_fk;
                List<string> lista = new List<string>();
                ListaPerfil.DataSource = _model.listaPerfilUsuario(cadastro);
                ListaPerfil.DataBind();
            }
        }

        public void EventosBotoes(bool tipo, string tipoEvento)
        {
            imgEditar.Visible = tipo;
            imgExcluir.Visible = tipo;
            imgSalvar.Visible = tipo;
            imgCancelar.Visible = tipo;

            if (tipoEvento == "Editar")
            {
                imgExcluir.Visible = false;
                imgEditar.Visible = false;
            }

            if (tipoEvento == "Salvar")
            {
                // imgEditar.Visible = true;
                imgExcluir.Visible = true;
                imgSalvar.Visible = true;
            }

        }

        public void CarregaStatusUsuario(int idPerfil)
        {
            listStatusPendencia.DataSource = chamadoMovel.listaStatus(idPerfil);
            listStatusPendencia.DataBind();
        }

        public void salvaChamado()
        {
            List<string> ListaNewChamado = new List<string>();
            ListaNewChamado = chamadoMovel.InsereChamado(GetChamado());
            foreach (var item in ListaNewChamado)
            {
                SalvarImagem(item);
                txtCodigo.Text = item.ToString();
            }

        }

        public void salvarAlteracao()
        {

        }


        public int retornaPerfil()
        {
            int perfil = 0;
            switch (ListaPerfil.Text)
            {
                case "Administrador":
                    perfil = 1;
                    break;

                case "Desenvolvedor":
                    perfil = 2;
                    break;

                case "Analista":
                    perfil = 3;
                    break;

                case "Homologação":
                    perfil = 4;
                    break;

                case "Usuário Site":
                    perfil = 5;
                    break;
            }

            return perfil;
        }


        public void SalvarImagem(string chamado)
        {
            if (fupImagem.HasFile)
            {
                string caminho = "~/Chamados/Imagens/";
                string NewPasta = Server.MapPath(caminho);

                if (!Directory.Exists(NewPasta))
                {
                    Directory.CreateDirectory(@"" + NewPasta);
                }

                fupImagem.SaveAs(NewPasta + chamado + ".jpg");
            }
        }



        #endregion
        private void AchaEvento()
        {
            imgSalvar.Click += imgSalvar_Click;
            imgExcluir.Click += imgExcluir_Click;
            imgCancelar.Click += imgCancelar_Click;
            imgEditar.Click += imgEditar_Click;
        }

        #region Eventos Botoes

        void imgSalvar_Click(object sender, EventArgs e)
        {
            EventosBotoes(false, "Salvar");

            // if (retornarAlteraSalvar().ToString() == "Editar")
            salvaChamado();
        }

        void imgExcluir_Click(object sender, EventArgs e)
        {

        }

        void imgCancelar_Click(object sender, EventArgs e)
        {
            EventosBotoes(false, "Salvar");
        }

        void imgEditar_Click(object sender, EventArgs e)
        {
            EventosBotoes(true, "Editar");
            DefineAlteraSalvar("Editar");
            CarregaStatusUsuario(1); // incluir id do Usuario para funcionar 
        }
        #endregion

        public Chamados GetChamado()
        {
            Chamados chamados = new Chamados();
            chamados.Titulo = txtTitulo.Text;
            chamados.Id_perfil = retornaPerfil();
            chamados.Descricao = txtDescricao.Text;
            chamados.Dt_abertura = dataHoraChamado.Text;
            // chamados.Dt_finalizado = dataHoraChamadoFinalizado.Text;
            chamados.Id_status_fk = 1;
            // Recupera dados  do usuario da sessão 
            Usuario_cadastro usu = new Usuario_cadastro();
            usu = ((Usuario_cadastro)Session[Constantes.Instancia.ChaveDadosUsuario]);
            if (usu != null)
            {
                chamados.Id_usuario_criacao = usu.Id_usuario;
            }
            return chamados;
        }

        public Chamados carregaEntidadeChamado()
        {
            Chamados chamados = new Chamados();
            chamados.Id_chamado = Convert.ToInt32(txtCodigo.Text);
            chamados.Titulo = txtTitulo.Text;
            chamados.Id_perfil = retornaPerfil();
            chamados.Descricao = txtDescricao.Text;
            chamados.Dt_abertura = dataHoraChamado.Text;
            chamados.Dt_finalizado = dataHoraChamadoFinalizado.Text;
            chamados.Id_status_fk = 1;
            return chamados;
        }

    }
}
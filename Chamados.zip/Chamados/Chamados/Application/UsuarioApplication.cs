﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;
using Infra;

namespace Entities
{
    public class UsuarioApplication
    {

        public static UsuarioApplication Instancia
        {
            get { return new UsuarioApplication(); }
        }

        public Usuario_cadastro ObterLogin_senha(string Login)
        {
            usuariosRepository _usuarioRepository = new usuariosRepository();
            return _usuarioRepository.ObterLogin_senha(Login);
        }

        public List<Usuario_cadastro> ListarUsuarios()
        {
            usuariosRepository _usuarioRepository = new usuariosRepository();
            return _usuarioRepository.ListarUsuarios();
        }

        public List<Usuario_Perfil> listaPerfil()
        {
            usuariosRepository _usuarioRepository = new usuariosRepository();
            return _usuarioRepository.listaPerfil();
        }

        public void InsereUsuario(Usuario_cadastro Usu)
        {
            usuariosRepository _usuarioRepository = new usuariosRepository();
            _usuarioRepository.InsereUsuario(Usu);
        }

        public Usuario_Perfil listaPerfisl(Usuario_Perfil cadastro)
        {
            usuariosRepository _usuarioRepository = new usuariosRepository();
            return _usuarioRepository.listaPerfils(cadastro);
        }

        public List<Usuario_Perfil> listaPerfilUsu(int IdPerfil)
        {
            usuariosRepository _usuarioRepository = new usuariosRepository();
            return _usuarioRepository.listaPerfilUsu(IdPerfil);
        }

        public List<string> listaPerfilUsuario(Usuario_Perfil Perfil)
        {
            usuariosRepository _usuarioRepository = new usuariosRepository();
            return _usuarioRepository.listaPerfilUsuario(Perfil);
        }

        public IList<lMenuLista> ListarMmenus(Usuario_cadastro usuario)
        {
            usuariosRepository _usuarioRepositoty = new usuariosRepository();
            return _usuarioRepositoty.ListarMmenus(usuario);
        }
    }
}

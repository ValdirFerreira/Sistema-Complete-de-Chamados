﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;
using Infra;


namespace Application
{
    public class ChamadosApplication
    {
        public static ChamadosApplication Instancia
        {
            get { return new ChamadosApplication(); }
        }

        public Chamados ObterChamado(int id)
        {
            chamadosRepository _chamadosRepository = new chamadosRepository();
            return _chamadosRepository.ObterChamado(id);
        }

        public void InserirChamado(Chamados NovoChamado)
        {
            chamadosRepository _chamadosRepository = new chamadosRepository();
            _chamadosRepository.InserirChamado(NovoChamado);
        }

        public void AlterarCurriculo(Chamados chamado)
        {
            chamadosRepository _chamadosRepository = new chamadosRepository();
            _chamadosRepository.AlterarCurriculo(chamado);
        }

        public void ExcluirChamado(Chamados chamado)
        {
            chamadosRepository _chamadosRepository = new chamadosRepository();
            _chamadosRepository.ExcluirChamado(chamado);
        }

        public List<string> listaStatus(int idPerfil)
        {
            chamadosRepository _chamadosRepository = new chamadosRepository();
           return _chamadosRepository.listaStatus(idPerfil);
        }


        public List<string> InsereChamado(Chamados chamado)
        {
            chamadosRepository _chamadosRepository = new chamadosRepository();
            return _chamadosRepository.InsereChamado(chamado);
        }

        public IList<Chamados> ListarChamados(Chamados chamados)
        {
            chamadosRepository _chamadosRepository = new chamadosRepository();
            return _chamadosRepository.ListarChamados(chamados);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;
using Domain;
using Infra.Helper;
using NHibernate.Criterion;
using System.Reflection;
using NHibernate.Mapping;
using NHibernate;
using NHibernate.SqlCommand;
using System.Collections;

namespace Infra
{
    public class usuariosRepository : IUsuarios
    {
        #region IUsuarios Members
        private const String ConnectionString = @"Integrated Security=SSPI;Server=VALDIR-PC;database=chamados;Enlist=false;Pooling=False;";

        public Usuario_cadastro ObterLogin_senha(string Login)
        {
            DefaultARService _service = new DefaultARService();
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(Usuario_cadastro).Assembly };
            return _service.Execute<Usuario_cadastro, Usuario_cadastro>(
                session => session
                    .CreateCriteria<Usuario_cadastro>("Usuario_cadastro")
                    .Add(Restrictions.Eq("Usuario_cadastro.Apelido", Login))
            .List<Usuario_cadastro>().First());
        }

        #endregion

        public List<Usuario_cadastro> ListarUsuarios()
        {
            DefaultARService _service = new DefaultARService();

            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(Usuario_cadastro).Assembly };

            return _service.Execute<Usuario_cadastro, List<Usuario_cadastro>>(
               session => session
                   .CreateCriteria<Usuario_cadastro>("id_usuario")
                   .List<Usuario_cadastro>().ToList()
               );
        }

        public List<Usuario_Perfil> listaPerfil()
        {
            DefaultARService _servico = new DefaultARService();
            _servico.ConnectionString = ConnectionString;
            _servico.AssemblyHolder = new Assembly[] { typeof(Usuario_Perfil).Assembly };

            return _servico.Execute<Usuario_Perfil, List<Usuario_Perfil>>(
                session => session
                    .CreateCriteria<Usuario_Perfil>("id_perfil")
                    .List<Usuario_Perfil>().ToList()
                    );
        }

        public void InsereUsuario(Usuario_cadastro Usu)
        {
            DefaultARService _servico = new DefaultARService();
            _servico.ConnectionString = ConnectionString;
            _servico.AssemblyHolder = new Assembly[] { typeof(Usuario_cadastro).Assembly };

            _servico.Insert<Usuario_cadastro>(Usu);
        }


        #region IUsuarios Members


        public Usuario_Perfil listaPerfils(Usuario_Perfil cadastro)
        {
            int perfil = cadastro.IdPerfil;
            DefaultARService _service = new DefaultARService();
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(Usuario_Perfil).Assembly };
            return _service.Execute<Usuario_Perfil, Usuario_Perfil>(
                session => session
                    .CreateCriteria<Usuario_Perfil>("Usuario_Perfil")
                    .Add(Restrictions.Eq("Usuario_Perfil.IdPerfil", perfil))
            .List<Usuario_Perfil>().First());
        }

        #endregion

        public List<Usuario_Perfil> listaPerfilUsu(int IdPerfil)
        {

            DefaultARService _service = new DefaultARService();
            Usuario_Perfil ser = new Usuario_Perfil();
            ser.IdPerfil = IdPerfil;
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(Usuario_Perfil).Assembly };
            return _service.Execute<Usuario_Perfil, List<Usuario_Perfil>>(
                session => session
                     .CreateSQLQuery("Exec PerfilAcesso ?")
                     .SetParameter(0, ser.IdPerfil)
                     .List<Usuario_Perfil>().ToList());

        }

        public List<string> listaPerfilUsuario(Usuario_Perfil Perfil)
        {
            DefaultARService _service = new DefaultARService();
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(List<string>).Assembly };
            return _service.Execute<List<string>, List<string>>(
                Session => Session
                    .CreateSQLQuery("Exec PerfilAcesso ?")
                    .SetParameter(0, Perfil.IdPerfil)
                    .List<string>().ToList());
        }


        public IList<lMenuLista> ListarMmenus(Usuario_cadastro usuario)
        {
            DefaultARService _servico = new DefaultARService();
            _servico.ConnectionString = ConnectionString;
            _servico.AssemblyHolder = new Assembly[] { typeof(IList<lMenuLista>).Assembly };

            var lista = _servico.
               Execute<lMenuLista, IList<lMenuLista>>(
               session => session.CreateCriteria<lMenuLista>()

                   .List<lMenuLista>().ToList()
                   );

            var ListaUsuarioMenu = menusUsuario(usuario);

            List<lMenuLista> list = new List<lMenuLista>();
            foreach (var item in lista)
            {
                foreach (var items in ListaUsuarioMenu)
                {
                    if (item.IdMenu == items )
                    {
                        list.Add(item);
                    }
                }
            }

            return list;

        }


        public IList<int> menusUsuario(Usuario_cadastro usuario)
        {
            //DefaultARService _servico = new DefaultARService();
            //_servico.ConnectionString = ConnectionString;
            //_servico.AssemblyHolder = new Assembly[] { typeof(PerfilMenu).Assembly };

            //return _servico.
            //   Execute<PerfilMenu, List<PerfilMenu>>(
            //   session => session.CreateCriteria<PerfilMenu>("PerfilMenu")

            //       .Add(Restrictions.Eq("PerfilMenu.Id_perfil", usuario.Id_perfil_fk))
            //       .List<PerfilMenu>().ToList()
            DefaultARService _service = new DefaultARService();
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(List<int>).Assembly };
            return _service.Execute<List<int>, List<int>>(
                Session => Session
                    .CreateSQLQuery("Exec Listar_PerfilMenu ?")
                    .SetParameter(0, usuario.Id_perfil_fk)
                    .List<int>().ToList());

        }

        #region IUsuarios Members
        #endregion
        #region IUsuarios Members
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Domain;
using Entities;
using Infra.Helper;
using System.Reflection;
using NHibernate.Criterion;

namespace Infra
{
    public class chamadosRepository : Ichamados_Repository
    {
        private const String ConnectionString = @"Integrated Security=SSPI;Server=VALDIR-PC;database=chamados;Enlist=false;Pooling=False;";
        #region Ichamados_Repository Members
       

        public Chamados ObterChamado(int id)
        {

            DefaultARService _service = new DefaultARService();
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(Chamados).Assembly };
            return _service.Execute<Chamados, Chamados>(
                session => session
                    .CreateCriteria<Chamados>("Chamados").Add(Restrictions.Eq("Chamados.id_chamados", id))
            .List<Chamados>().First());

        }

        public List<Chamados> ListarChamados()
        {
            throw new NotImplementedException();
        }

        public void InserirChamado(Chamados NovoChamado)
        {
            DefaultARService _service = new DefaultARService();

            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(Chamados).Assembly };
            _service.Insert<Chamados>(NovoChamado);
        }

        public void AlterarCurriculo(Chamados chamado)
        {
            DefaultARService _Service = new DefaultARService();
            _Service.ConnectionString = ConnectionString;
            _Service.AssemblyHolder = new Assembly[] { typeof(Chamados).Assembly };
            _Service.Insert<Chamados>(chamado);
           
           
        }

        public void ExcluirChamado(Chamados chamado)
        {
            DefaultARService _service = new DefaultARService();
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(Chamados).Assembly };
            _service.Delete<Chamados>(chamado);
        }

        public void ExcluirChamado(int id)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Ichamados_Repository Members


        public List<string> listaStatus(int idPerfil)
        {
            DefaultARService _service = new DefaultARService();
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(List<string>).Assembly };
            return _service.Execute<List<string>, List<string>>(
               Session => Session
                   .CreateSQLQuery("Exec Status_Chamado ?")
                   .SetParameter(0, idPerfil)
                   .List<string>().ToList());
        }



        //DefaultARService _service = new DefaultARService();
        //    _service.ConnectionString = ConnectionString;
        //    _service.AssemblyHolder = new Assembly[] { typeof(List<string>).Assembly };
        //    return _service.Execute<List<string>, List<string>>(
        //        Session => Session
        //            .CreateSQLQuery("Exec PerfilAcesso ?")
        //            .SetParameter(0, Perfil.IdPerfil)
        //            .List<string>().ToList());



        #endregion

        #region Ichamados_Repository Members


        public List<string> InsereChamado(Chamados NovoChamado)
        {
            DefaultARService _service = new DefaultARService();
            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(List<string>).Assembly };
            return _service.Execute<List<string>, List<string>>(
               Session => Session
                   .CreateSQLQuery("Exec Insere_Chamado ?,?,?,?,?,?,?")
                   .SetParameter(0, NovoChamado.Titulo)
                   .SetParameter(1, NovoChamado.Id_perfil)
                   .SetParameter(2, NovoChamado.Descricao)
                   .SetParameter(3, NovoChamado.Dt_abertura)
                   .SetParameter(4, NovoChamado.Dt_finalizado)
                   .SetParameter(5, NovoChamado.Id_status_fk)
                   .SetParameter(6, NovoChamado.Id_usuario_criacao)
                   .List<string>().ToList());
            
        }

        public IList<Chamados> ListarChamados(Chamados chamados)
        {
            DefaultARService _service = new DefaultARService();

            _service.ConnectionString = ConnectionString;
            _service.AssemblyHolder = new Assembly[] { typeof(Chamados).Assembly };

            return _service.Execute<Chamados, List<Chamados>>(
               session => session
                   .CreateCriteria<Chamados>()
                   .List<Chamados>().ToList()
               );
        }



       

        #endregion
    }
}

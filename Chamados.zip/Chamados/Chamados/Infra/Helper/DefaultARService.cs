﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Data;
using System.Data.SqlClient;
using Castle.ActiveRecord;
using Castle.ActiveRecord.Framework.Config;
using NHibernate;
using NHibernate.Cfg;

using System.Reflection;
using NHibernate.Criterion;
using Entities;



namespace Infra.Helper
{

    public class DefaultARService : ActiveRecordBase
    {


        // Probriedades basica 
        public String ConnectionString { get; set; }

        // Inicializar Assemble
        public Assembly[] AssemblyHolder
        {
            set;
            private get;
        }

        //Retorna uma Conexão 
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IDbConnection GetConnection()
        {
            return new SqlConnection(this.ConnectionString);
        }




        //Metodos Basicos
        /// <summary>
        /// 
        /// </summary>
        //protected void InicializarAR()
        //{

        //    this.AssemblyHolder = new Assembly[] 
        //    {
        //        //typeof(menu).Assembly
        //    };


        //    if (ActiveRecordStarter.IsInitialized) { return; }

        //    IDictionary<string, string> properties = new Dictionary<string, string>();

        //    properties.Add("connection.driver_class", "NHibernate.Driver.SqlClientDriver");
        //    properties.Add("dialect", "NHibernate.Dialect.MsSql2005Dialect");
        //    properties.Add("connection.provider", "NHibernate.Connection.DriverConnectionProvider");
        //    properties.Add("proxyfactory.factory_class", "NHibernate.ByteCode.Castle.ProxyFactoryFactory, NHibernate.ByteCode.Castle");
        //    properties.Add("connection.connection_string", ConnectionString);
        //    properties.Add("hibernate.show_sql", "true");

        //    InPlaceConfigurationSource configSource = new InPlaceConfigurationSource();
        //    configSource.Add(typeof(ActiveRecordBase), properties);
        //    ActiveRecordStarter.Initialize(AssemblyHolder, configSource);
        //}

        public void InicializarAR()
        {
            this.AssemblyHolder = new Assembly[] 
            {
                typeof(lMenuLista).Assembly
            };

            if (ActiveRecordStarter.IsInitialized) { return; }

            IDictionary<string, string> properties = new Dictionary<string, string>();

            properties.Add("connection.driver_class", "NHibernate.Driver.SqlClientDriver");
            properties.Add("dialect", "NHibernate.Dialect.MsSql2005Dialect");
            properties.Add("connection.provider", "NHibernate.Connection.DriverConnectionProvider");
            properties.Add("proxyfactory.factory_class", "NHibernate.ByteCode.Castle.ProxyFactoryFactory, NHibernate.ByteCode.Castle");
            properties.Add("connection.connection_string", ConnectionString);
            properties.Add("hibernate.show_sql", "true");

            InPlaceConfigurationSource configSource = new InPlaceConfigurationSource();
            configSource.Add(typeof(ActiveRecordBase), properties);

            ActiveRecordStarter.Initialize(AssemblyHolder, configSource);
        }

        // Liberar Session 

        public void RelaseSession(ISession session)
        {
            session.Clear();
            session.Dispose();

        }

        public virtual void Insert<TSource>(TSource entity)
        {
            InicializarAR();//configuração da conexão   
            ISession session = SessionHolder.GetSessionFactory(typeof(TSource)).OpenSession(GetConnection());
            try
            {
                if (session.Connection.State != ConnectionState.Open)
                { session.Connection.Open(); }
                session.Save(entity);

            }
            catch (Exception ex)
            {
                throw (new Exception(ex.Message, ex));
            }
            finally
            {
                session.Connection.Close();
                session.Connection.Dispose();
                RelaseSession(session);
            }
        }
        public virtual void Update<Tsourse>(Tsourse entity)
        {
            InicializarAR();// configuração da conexão 
            ISession session = SessionHolder.GetSessionFactory(typeof(Tsourse)).OpenSession(GetConnection());

            try
            {
                if (session.Connection.State != ConnectionState.Open)
                { session.Connection.Open(); }
                session.SaveOrUpdate(entity);// Atualiza entity
            }
            catch (Exception ex)
            {
                throw (new Exception(ex.Message, ex));

            }
            finally
            {
                session.Connection.Close();
                session.Connection.Dispose();
                RelaseSession(session);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="Tsource"></typeparam>
        /// <param name="entity"></param>
        public virtual void Delete<Tsource>(Tsource entity)
        {
            InicializarAR(); // configuração da conexão
            ISession session = SessionHolder.GetSessionFactory(typeof(Tsource)).OpenSession(GetConnection());

            try
            {
                if (session.Connection.State != ConnectionState.Open)
                { session.Connection.Open(); }
                session.Delete(entity);
            }
            catch (Exception ex)
            {
                throw (new Exception(ex.Message, ex));
            }
            finally
            {
                session.Connection.Close();
                session.Connection.Dispose();
                RelaseSession(session);
            }
        }

        public virtual void ExecuteNoQuery<TSource>(Action<ISession> function)
        {
            InicializarAR(); //Configuração da conexão 
            ISession session = SessionHolder.GetSessionFactory(typeof(TSource)).OpenSession(GetConnection());

            try
            {
                if (session.Connection.State != ConnectionState.Open)
                { session.Connection.Open(); }
                function(session);
            }
            catch (Exception ex)
            {
                throw (new Exception(ex.Message, ex));
            }
            finally
            {
                session.Connection.Close();
                session.Connection.Dispose();
                RelaseSession(session);
            }
        }

        public virtual TResult Execute<TSource, TResult>(Func<ISession, TResult> function)
        {
            TResult result = default(TResult);
            this.ExecuteNoQuery<TSource>(session => result = function(session));
            return result;
        }


        // montando parametros com a procedure 
        public IDbCommand CreateComand(ISession session, string procedureNome, Func<ISession, IDbCommand, IDbDataParameter[]> function)
        {
            IDbCommand command = session.Connection.CreateCommand();
            command.CommandTimeout = 60;
            command.CommandText = procedureNome;
            command.CommandType = CommandType.StoredProcedure;

            // verifica se tem parametros 
            if (function == null) { return command; }

            IDbDataParameter[] parameters = function(session, command);
            if (parameters != null)
            {
                foreach (IDbDataParameter parameter in parameters)
                { command.Parameters.Add(parameter); }
            }
            return command;


        }


        public virtual void ExecuteProcedureNonQuery<TSource>(string procedureName, Func<ISession, IDbCommand, IDbDataParameter[]> function)
          where TSource : class
        {
            this.ExecuteNoQuery<TSource>(
                delegate(ISession session)
                {
                    CreateComand(session, procedureName, function)
                        .ExecuteNonQuery();
                });
        }


        //public virtual IList<TResult> ExecuteProcedure2EntityList<TSource, TResult>(string procedureName, Func<ISession, IDbCommand, IDbDataParameter[]> function)
        //    where TSource : class, TResult
        //    where TResult : class, TResult
        //{
        //    return this.ExecuteProcedure2EntityList<TSource, TResult>(procedureName, function);
        //}




    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;
using Facade;

namespace Model
{
    public class ChamadosModel
    {
        public Chamados ObterCurriculo(int id)
        {
            return ChamadosFacade.Instancia.ObterChamado(id);
        }

        public void InserirChamado(Chamados NovoChamado)
        {
            ChamadosFacade.Instancia.InserirChamado(NovoChamado);
        }

        public void AlterarCurriculo(Chamados chamado)
        {
            ChamadosFacade.Instancia.AlterarCurriculo(chamado);
        }

        public void ExcluirChamado(Chamados chamado)
        {
            ChamadosFacade.Instancia.ExcluirChamado(chamado);
        }

        public List<string> listaStatus(int idPerfil)
        {
            return ChamadosFacade.Instancia.listaStatus(idPerfil);
        }

        public List<string> InsereChamado(Chamados chamado)
        {

            return ChamadosFacade.Instancia.InsereChamado(chamado);
        }

        public IList<Chamados> ListarChamados(Chamados chamados)
        {
            return ChamadosFacade.Instancia.ListarChamados(chamados);
        }
    }
}

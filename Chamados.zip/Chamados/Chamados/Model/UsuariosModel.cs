﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entities;
using Facade;

namespace Model
{
    public class UsuariosModel
    {
        public Usuario_cadastro ObterLogin_senha(string Login)
        {
            return UsuarioFacade.Instancia.ObterLogin_senha(Login);
        }

        public List<Usuario_cadastro> ListarUsuarios()
        {
            return UsuarioFacade.Instancia.ListarUsuarios();
        }

        public List<Usuario_Perfil> listaPerfil()
        {
            return UsuarioFacade.Instancia.listaPerfil();
        }

        public void InsereUsuario(Usuario_cadastro Usu)
        {
            UsuarioFacade.Instancia.InsereUsuario(Usu);
        }

        public Usuario_Perfil listaPerfils(Usuario_Perfil cadastro)
        {
            return UsuarioFacade.Instancia.listaPerfils(cadastro);
        }      

        public List<Usuario_Perfil> listaPerfilUsu(int IdPerfil)
        {
            return UsuarioFacade.Instancia.listaPerfilUsu(IdPerfil);
        }

        public List<string> listaPerfilUsuario(Usuario_Perfil Perfil)
        {
            return UsuarioFacade.Instancia.listaPerfilUsuario(Perfil);
        }

        public IList<lMenuLista> Listar(Usuario_cadastro usuario)
        {
            return UsuarioFacade.Instancia.ListarMmenus(usuario);
        }


    }
}
